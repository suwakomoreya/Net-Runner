NET RUNNER
==========

A terminal Caesar-cipher hacking game.

HOW TO RUN
----------
Double-click Net-Runner.exe (Windows x64).
Keep Net-Runner.exe, the included DLLs, and the data folder together in
the same directory.

CONTROLS
--------
Up / Down     Navigate menus
Enter         Select / submit answer
Esc           Back
Backspace     Delete a character

GAMEPLAY
--------
Open "Browse available contracts", pick a job, then choose "Start cipher".
Decrypt the Caesar cipher and type the answer before the timer runs out.
Answers are case-sensitive; the game asks for CAPS.

Progress is saved to data\playerdata.json and data\contracts.json.
Delete data\playerdata.json to reset your character.
